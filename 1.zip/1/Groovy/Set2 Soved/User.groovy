
class User 
{
	long id
	String name
	String department

	public User(long id, String name, String department)
	{
		this.id = id
		this.name = name
		this.department = department
	}
}
